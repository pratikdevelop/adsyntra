import { getProviderAccessToken } from "../../utils/provider-token.utils.js";

export interface MetaAdsCreationContext {
  adAccountId: string;
  accessToken: string;
  apiVersion: string;
}

export type MetaAdsBidStrategy =
  | "LOWEST_COST_WITHOUT_CAP"
  | "LOWEST_COST_WITH_BID_CAP"
  | "COST_CAP"
  | "LOWEST_COST_WITH_MIN_ROAS";
export interface CreateMetaAdsCampaignInput {
  /** Uses the shared campaign name when omitted by the caller. */
  name: string;
  /** Meta-native objective, e.g. OUTCOME_TRAFFIC or OUTCOME_SALES. */
  objective: string;
  /** Use [] when the campaign is not in a special ad category. */
  specialAdCategories?: string[];
  buyingType?: "AUCTION" | "RESERVED";
  isAdsetBudgetSharingEnabled?: boolean;
  /** Defaults to true. A validation-only call does not create a Meta object. */
  validateOnly?: boolean;
  /** Required when validateOnly is false. */
  confirm?: boolean;
  dailyBudgetAmount?: number;
  budgetCurrency?: string;
  bidStrategy?: MetaAdsBidStrategy;
}

export interface CreateMetaAdsAdInput {
  name: string;
  adSetId: string;
  creativeId: string;

  validateOnly?: boolean;
  confirm?: boolean;
}

export interface MetaAdsAdCreationResult {
  validateOnly: boolean;
  adAccountId: string;
  adId: string | null;
  adSetId: string;
  creativeId: string;
  name: string;
  status: "PAUSED";
  metaResponse: Record<string, unknown> | null;
}

export type MetaAdsCallToAction =
  | "LEARN_MORE"
  | "SHOP_NOW"
  | "SIGN_UP"
  | "CONTACT_US"
  | "GET_QUOTE"
  | "DOWNLOAD";

export interface CreateMetaAdsAdCreativeInput {
  name: string;
  pageId: string;
  instagramActorId?: string;

  primaryText: string;
  headline: string;
  description?: string;

  imageUrl: string;
  destinationUrl: string;
  callToAction: MetaAdsCallToAction;

  validateOnly?: boolean;
  confirm?: boolean;
}

export interface MetaAdsAdCreativeCreationResult {
  validateOnly: boolean;
  adAccountId: string;
  creativeId: string | null;
  name: string;
  pageId: string;
  metaResponse: Record<string, unknown> | null;
}
export interface MetaAdsCampaignCreationResult {
  validateOnly: boolean;
  adAccountId: string;
  campaignId: string | null;
  name: string;
  objective: string;
  status: "PAUSED";
  buyingType: "AUCTION" | "RESERVED";
  metaResponse: Record<string, unknown> | null;
}

interface MetaApiErrorBody {
  error?: {
    message?: string;
    type?: string;
    code?: number;
    error_subcode?: number;
    fbtrace_id?: string;
  };
  [key: string]: unknown;
}

export class MetaAdsCampaignCreationError extends Error {
  constructor(
    message: string,
    public statusCode = 500,
    public details?: unknown,
  ) {
    super(message);
    this.name = "MetaAdsCampaignCreationError";
  }
}

function toMetaMinorCurrencyUnits(amount: number, currency: string): string {
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new MetaAdsCampaignCreationError(
      "Daily budget must be a positive number.",
      400,
    );
  }

  const normalizedCurrency = currency.trim().toUpperCase();

  if (!/^[A-Z]{3}$/.test(normalizedCurrency)) {
    throw new MetaAdsCampaignCreationError(
      "A valid three-letter account currency is required.",
      400,
    );
  }

  let fractionDigits: any;

  try {
    fractionDigits = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: normalizedCurrency,
    }).resolvedOptions().maximumFractionDigits;
  } catch {
    throw new MetaAdsCampaignCreationError("Unsupported budget currency.", 400);
  }

  const minorUnits = Math.round(
    (amount + Number.EPSILON) * 10 ** fractionDigits,
  );

  if (!Number.isSafeInteger(minorUnits) || minorUnits <= 0) {
    throw new MetaAdsCampaignCreationError(
      "Daily budget is outside the supported amount range.",
      400,
    );
  }

  return String(minorUnits);
}

export type MetaLocationType = "home" | "recent" | "travel_in";

export type MetaDistanceUnit = "mile" | "kilometer";

export interface MetaGeoLocationKey {
  key: string;
}

export interface MetaGeoLocationCity {
  key: string;
  radius?: number;
  distance_unit?: MetaDistanceUnit;
}

export interface MetaGeoCustomLocation {
  latitude: number;
  longitude: number;
  radius: number;
  distance_unit: MetaDistanceUnit;
  address_string?: string;
  country?: string;
  region_id?: number;
  primary_city_id?: number;
}

export interface MetaGeoLocations {
  countries?: string[];
  country_groups?: string[];
  regions?: MetaGeoLocationKey[];
  cities?: MetaGeoLocationCity[];
  zips?: MetaGeoLocationKey[];
  custom_locations?: MetaGeoCustomLocation[];
  location_types?: MetaLocationType[];
}

export type MetaExcludedGeoLocations = Omit<MetaGeoLocations, "location_types">;

export interface MetaAdsTargeting {
  geo_locations: MetaGeoLocations;
  excluded_geo_locations?: MetaExcludedGeoLocations;

  age_min?: number;
  age_max?: number;
  genders?: number[];

  [key: string]: unknown;

  // Advantage+ audience age suggestion.
  // This is a suggestion, not the same as hard age limits.
  age_range?: [number, number];

  // Language targeting.
  // Values are Meta locale IDs returned by targeting search.
  locales?: number[];

  // Optional demographic targeting.
  education_statuses?: number[];
  relationship_statuses?: number[];
  college_years?: number[];
}


export interface MetaAdsAdSetCreationResult {
  validateOnly: boolean;
  adAccountId: string;
  campaignId: string;
  adSetId: string | null;
  name: string;
  status: "PAUSED";
  metaResponse: Record<string, unknown> | null;
}

export interface CreateMetaAdsAdSetInput {
  campaignId: string;
  name: string;

  specialAdCategories?: string[];
  optimization_goal: string;
  billing_event: string;
  targeting: MetaAdsTargeting;

  dailyBudgetAmount?: number;
  budgetCurrency?: string;

  bid_strategy?: MetaAdsBidStrategy;
  bidAmountInput?: number;

  bid_constraints?: {
    roas_average_floor: number;
  };

  promoted_object?: {
    pixel_id: string;
    custom_event_type?: string;
  };

  validateOnly?: boolean;
  confirm?: boolean;
}

export interface MetaAdsAdSetCreationResult {
  validateOnly: boolean;
  adAccountId: string;
  campaignId: string;
  adSetId: string | null;
  name: string;
  status: "PAUSED";
  metaResponse: Record<string, unknown> | null;
}

function normalizeAdAccountId(value: string): string {
  const normalized = value.trim();
  const accountId = normalized.startsWith("act_")
    ? normalized
    : `act_${normalized}`;

  if (!/^act_\d+$/.test(accountId)) {
    throw new MetaAdsCampaignCreationError(
      "Invalid Meta Ads account ID. Expected a numeric ID or act_{accountId}.",
      400,
    );
  }

  return accountId;
}

function getMetaApiVersion(): string {
  const version = process.env.META_ADS_API_VERSION?.trim() || "v27.0";

  if (!/^v\d+\.\d+$/.test(version)) {
    throw new MetaAdsCampaignCreationError(
      "Invalid META_ADS_API_VERSION. Expected a version such as v27.0.",
      500,
    );
  }

  return version;
}

function validateCreateCampaignInput(
  input: CreateMetaAdsCampaignInput,
): Required<
  Pick<
    CreateMetaAdsCampaignInput,
    "name" | "objective" | "specialAdCategories" | "buyingType" | "validateOnly"
  >
> & {
  isAdsetBudgetSharingEnabled?: boolean;
  confirm?: boolean;
  dailyBudgetMinorUnits?: string;
  bidStrategy?: MetaAdsBidStrategy;
} {
  const name = input.name?.trim();
  if (!name || name.length > 255 || /[\0\r\n]/.test(name)) {
    throw new MetaAdsCampaignCreationError(
      "Campaign name is required and must not exceed 255 characters.",
      400,
    );
  }

  const objective = input.objective?.trim().toUpperCase();
  if (!objective || objective.length > 120) {
    throw new MetaAdsCampaignCreationError(
      "A valid Meta Ads campaign objective is required.",
      400,
    );
  }

  const specialAdCategories = input.specialAdCategories ?? [];
  if (
    !Array.isArray(specialAdCategories) ||
    !specialAdCategories.every(
      (category) =>
        typeof category === "string" &&
        category.trim().length > 0 &&
        category.trim().length <= 80,
    )
  ) {
    throw new MetaAdsCampaignCreationError(
      "specialAdCategories must be an array of non-empty category strings.",
      400,
    );
  }

  const normalizedCategories = specialAdCategories.map((category) =>
    category.trim().toUpperCase(),
  );

  if (new Set(normalizedCategories).size !== normalizedCategories.length) {
    throw new MetaAdsCampaignCreationError(
      "specialAdCategories must not contain duplicate values.",
      400,
    );
  }

  const buyingType = input.buyingType ?? "AUCTION";
  if (buyingType !== "AUCTION" && buyingType !== "RESERVED") {
    throw new MetaAdsCampaignCreationError(
      "buyingType must be AUCTION or RESERVED.",
      400,
    );
  }

  if (
    input.isAdsetBudgetSharingEnabled !== undefined &&
    typeof input.isAdsetBudgetSharingEnabled !== "boolean"
  ) {
    throw new MetaAdsCampaignCreationError(
      "isAdsetBudgetSharingEnabled must be a boolean.",
      400,
    );
  }

  const validateOnly = input.validateOnly ?? true;
  if (typeof validateOnly !== "boolean") {
    throw new MetaAdsCampaignCreationError(
      "validateOnly must be a boolean.",
      400,
    );
  }

  if (!validateOnly && input.confirm !== true) {
    throw new MetaAdsCampaignCreationError(
      "Live Meta Ads campaign creation requires confirm: true and validateOnly: false.",
      400,
    );
  }

  let dailyBudgetMinorUnits: string | undefined;

  if (input.dailyBudgetAmount !== undefined) {
    if (
      typeof input.dailyBudgetAmount !== "number" ||
      !input.budgetCurrency?.trim()
    ) {
      throw new MetaAdsCampaignCreationError(
        "Daily budget and account currency must be provided together.",
        400,
      );
    }

    dailyBudgetMinorUnits = toMetaMinorCurrencyUnits(
      input.dailyBudgetAmount,
      input.budgetCurrency,
    );
  }

  const allowedBidStrategies: MetaAdsBidStrategy[] = [
    "LOWEST_COST_WITHOUT_CAP",
    "LOWEST_COST_WITH_BID_CAP",
    "COST_CAP",
    "LOWEST_COST_WITH_MIN_ROAS",
  ];

  if (
    input.bidStrategy !== undefined &&
    !allowedBidStrategies.includes(input.bidStrategy)
  ) {
    throw new MetaAdsCampaignCreationError(
      "Unsupported Meta Ads bid strategy.",
      400,
    );
  }

  return {
    dailyBudgetMinorUnits,
    bidStrategy: input.bidStrategy,
    name,
    objective,
    specialAdCategories: normalizedCategories,
    buyingType,
    isAdsetBudgetSharingEnabled: input.isAdsetBudgetSharingEnabled,
    validateOnly,
    confirm: input.confirm,
  };
}

function getMetaErrorMessage(body: unknown, status: number): string {
  if (body && typeof body === "object" && "error" in body) {
    const error = (body as MetaApiErrorBody).error;
    if (error?.message) {
      const code = error.code === undefined ? "" : ` (code ${error.code})`;
      const type = error.type ? ` ${error.type}` : "";
      return `Meta Ads API request failed with HTTP ${status}${type}${code}: ${error.message}`;
    }
  }

  return `Meta Ads API request failed with HTTP ${status}.`;
}

export async function createMetaAdsAd(
  context: MetaAdsCreationContext,
  input: CreateMetaAdsAdInput,
): Promise<MetaAdsAdCreationResult> {
  // 1. Validate Ad name
  const name = input.name?.trim();

  if (!name || name.length > 255) {
    throw new MetaAdsCampaignCreationError(
      "Ad name is required and must not exceed 255 characters.",
      400,
    );
  }

  // 2. Validate Ad Set ID
  const adSetId = input.adSetId?.trim();

  if (!adSetId || !/^\d+$/.test(adSetId)) {
    throw new MetaAdsCampaignCreationError(
      "A valid numeric Ad Set ID is required.",
      400,
    );
  }

  // 3. Validate Creative ID
  const creativeId = input.creativeId?.trim();

  if (!creativeId || !/^\d+$/.test(creativeId)) {
    throw new MetaAdsCampaignCreationError(
      "A valid numeric Creative ID is required.",
      400,
    );
  }

  // 4. Validate mutation mode
  const validateOnly = input.validateOnly ?? true;

  if (typeof validateOnly !== "boolean") {
    throw new MetaAdsCampaignCreationError(
      "validateOnly must be a boolean.",
      400,
    );
  }

  if (!validateOnly && input.confirm !== true) {
    throw new MetaAdsCampaignCreationError(
      "Live Meta Ads creation requires validateOnly: false and confirm: true.",
      400,
    );
  }

  // 5. Validation-only response
  if (validateOnly) {
    return {
      validateOnly: true,
      adAccountId: context.adAccountId,
      adId: null,
      adSetId,
      creativeId,
      name,
      status: "PAUSED",
      metaResponse: null,
    };
  }

  // 6. Build Meta Graph API request
  const url = new URL(
    `https://graph.facebook.com/${context.apiVersion}/${context.adAccountId}/ads`,
  );

  const form = new URLSearchParams({
    name,
    adset_id: adSetId,
    creative: JSON.stringify({
      creative_id: creativeId,
    }),
    status: "PAUSED",
  });

  // 7. Call Meta API
  let response: Response;
  let responseBody: unknown;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${context.accessToken}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(30_000),
    });

    responseBody = await response.json().catch(() => null);
  } catch (error) {
    throw new MetaAdsCampaignCreationError(
      error instanceof Error
        ? `Could not reach Meta Graph API: ${error.message}`
        : "Could not reach Meta Graph API.",
      502,
    );
  }

  // 8. Handle API errors
  if (!response.ok) {
    throw new MetaAdsCampaignCreationError(
      getMetaErrorMessage(responseBody, response.status),
      response.status,
      responseBody,
    );
  }

  // 9. Verify Ad ID
  if (
    !responseBody ||
    typeof responseBody !== "object" ||
    !("id" in responseBody) ||
    typeof (responseBody as { id?: unknown }).id !== "string"
  ) {
    throw new MetaAdsCampaignCreationError(
      "Meta Ads returned a successful response without an Ad ID.",
      502,
      responseBody,
    );
  }

  const adId = (responseBody as { id: string }).id;

  return {
    validateOnly: false,
    adAccountId: context.adAccountId,
    adId,
    adSetId,
    creativeId,
    name,
    status: "PAUSED",
    metaResponse: responseBody as Record<string, unknown>,
  };
}

function normalizeMetaGeoLocations(
  value: MetaGeoLocations | MetaExcludedGeoLocations | undefined,
  fieldName: string,
  requireIncludedLocation = false,
): MetaGeoLocations | MetaExcludedGeoLocations {
  if (!value || typeof value !== "object") {
    throw new MetaAdsCampaignCreationError(
      `${fieldName} must be a valid location object.`,
      400,
    );
  }

  const normalized: MetaGeoLocations = {};

  // 1. Countries
  if (value.countries !== undefined) {
    if (
      !Array.isArray(value.countries) ||
      !value.countries.every(
        (country) =>
          typeof country === "string" && /^[A-Za-z]{2}$/.test(country.trim()),
      )
    ) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.countries must contain valid two-letter country codes.`,
        400,
      );
    }

    normalized.countries = [
      ...new Set(
        value.countries.map((country) => country.trim().toUpperCase()),
      ),
    ];
  }

  // 2. Country groups
  if (value.country_groups !== undefined) {
    const supportedGroups = [
      "africa",
      "asia",
      "europe",
      "north_america",
      "south_america",
      "oceania",
      "central_america",
      "caribbean",
    ];

    if (
      !Array.isArray(value.country_groups) ||
      !value.country_groups.every(
        (group) =>
          typeof group === "string" &&
          supportedGroups.includes(group.trim().toLowerCase()),
      )
    ) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.country_groups contains an unsupported group.`,
        400,
      );
    }

    normalized.country_groups = [
      ...new Set(
        value.country_groups.map((group) => group.trim().toLowerCase()),
      ),
    ];
  }

  // 3. Regions
  if (value.regions !== undefined) {
    if (
      !Array.isArray(value.regions) ||
      !value.regions.every(
        (item) => typeof item?.key === "string" && item.key.trim().length > 0,
      )
    ) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.regions must contain valid Meta region keys.`,
        400,
      );
    }

    normalized.regions = value.regions.map((item) => ({
      key: item.key.trim(),
    }));
  }

  // 4. Cities and optional radius
  if (value.cities !== undefined) {
    if (
      !Array.isArray(value.cities) ||
      !value.cities.every(
        (city) => typeof city?.key === "string" && city.key.trim().length > 0,
      )
    ) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.cities must contain valid Meta city keys.`,
        400,
      );
    }

    normalized.cities = value.cities.map((city) => {
      const hasRadius = city.radius !== undefined;
      const hasUnit = city.distance_unit !== undefined;

      if (hasRadius !== hasUnit) {
        throw new MetaAdsCampaignCreationError(
          "City radius and distance_unit must be provided together.",
          400,
        );
      }

      if (
        hasRadius &&
        (!Number.isFinite(city.radius) ||
          city.radius! <= 0 ||
          !["mile", "kilometer"].includes(city.distance_unit!))
      ) {
        throw new MetaAdsCampaignCreationError(
          "City radius must be positive and use mile or kilometer.",
          400,
        );
      }

      return {
        key: city.key.trim(),
        ...(hasRadius && {
          radius: city.radius,
          distance_unit: city.distance_unit,
        }),
      };
    });
  }

  // 5. Postal codes
  if (value.zips !== undefined) {
    if (
      !Array.isArray(value.zips) ||
      !value.zips.every(
        (zip) => typeof zip?.key === "string" && zip.key.trim().length > 0,
      )
    ) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.zips must contain valid Meta postal location keys.`,
        400,
      );
    }

    normalized.zips = value.zips.map((zip) => ({
      key: zip.key.trim(),
    }));
  }

  // 6. Custom radius locations
  if (value.custom_locations !== undefined) {
    if (!Array.isArray(value.custom_locations)) {
      throw new MetaAdsCampaignCreationError(
        `${fieldName}.custom_locations must be an array.`,
        400,
      );
    }

    normalized.custom_locations = value.custom_locations.map((location) => {
      if (
        !Number.isFinite(location.latitude) ||
        location.latitude < -90 ||
        location.latitude > 90
      ) {
        throw new MetaAdsCampaignCreationError(
          "Custom location latitude must be between -90 and 90.",
          400,
        );
      }

      if (
        !Number.isFinite(location.longitude) ||
        location.longitude < -180 ||
        location.longitude > 180
      ) {
        throw new MetaAdsCampaignCreationError(
          "Custom location longitude must be between -180 and 180.",
          400,
        );
      }

      if (
        !Number.isFinite(location.radius) ||
        location.radius <= 0 ||
        !["mile", "kilometer"].includes(location.distance_unit)
      ) {
        throw new MetaAdsCampaignCreationError(
          "Custom location requires a positive radius and valid distance unit.",
          400,
        );
      }

      return {
        latitude: location.latitude,
        longitude: location.longitude,
        radius: location.radius,
        distance_unit: location.distance_unit,
        ...(location.address_string?.trim() && {
          address_string: location.address_string.trim(),
        }),
        ...(location.country?.trim() && {
          country: location.country.trim().toUpperCase(),
        }),
        ...(location.region_id !== undefined && {
          region_id: location.region_id,
        }),
        ...(location.primary_city_id !== undefined && {
          primary_city_id: location.primary_city_id,
        }),
      };
    });
  }

  // 7. Location types
  if (value.location_types !== undefined) {
    const supportedTypes: MetaLocationType[] = ["home", "recent", "travel_in"];

    const types = value.location_types;

    const validCombination =
      Array.isArray(types) &&
      types.length > 0 &&
      types.length <= 2 &&
      types.every((type) => supportedTypes.includes(type)) &&
      new Set(types).size === types.length &&
      (types.length === 1 ||
        (types.length === 2 &&
          types.includes("home") &&
          types.includes("recent")));

    if (!validCombination) {
      throw new MetaAdsCampaignCreationError(
        "Location types must be home, recent, travel_in, or home and recent together.",
        400,
      );
    }

    normalized.location_types = types;
  }

  // 8. At least one included geographic selection is required
  if (requireIncludedLocation) {
    const hasLocation = Boolean(
      normalized.countries?.length ||
      normalized.country_groups?.length ||
      normalized.regions?.length ||
      normalized.cities?.length ||
      normalized.zips?.length ||
      normalized.custom_locations?.length,
    );

    if (!hasLocation) {
      throw new MetaAdsCampaignCreationError(
        "Select at least one country, region, city, postal code or custom location.",
        400,
      );
    }
  }

  return normalized;
}
function normalizeMetaNumericOptions(
  values: number[] | undefined,
  fieldName: string,
): number[] | undefined {
  if (values === undefined) {
    return undefined;
  }

  if (
    !Array.isArray(values) ||
    values.length === 0 ||
    !values.every(
      (value) =>
        Number.isSafeInteger(value) &&
        value > 0,
    )
  ) {
    throw new MetaAdsCampaignCreationError(
      `${fieldName} must contain positive integer IDs.`,
      400,
    );
  }

  return [...new Set(values)];
}
export async function createMetaAdsAdSet(
  context: MetaAdsCreationContext,
  input: CreateMetaAdsAdSetInput,
): Promise<MetaAdsAdSetCreationResult> {
  const name = input.name?.trim();
  const campaignId = input.campaignId?.trim();
  const optimizationGoal = input.optimization_goal?.trim().toUpperCase();
  const billingEvent = input.billing_event?.trim().toUpperCase();

  // 1. Validate Campaign ID
  if (!campaignId || !/^\d+$/.test(campaignId)) {
    throw new MetaAdsCampaignCreationError(
      "A valid numeric Meta campaign ID is required.",
      400,
    );
  }

  // 2. Validate Ad Set name
  if (!name || name.length > 255 || /[\0\r\n]/.test(name)) {
    throw new MetaAdsCampaignCreationError(
      "Ad Set name is required and must not exceed 255 characters.",
      400,
    );
  }

  // 3. Validate optimization goal and billing event
  if (!optimizationGoal || !billingEvent) {
    throw new MetaAdsCampaignCreationError(
      "Optimization goal and billing event are required.",
      400,
    );
  }
  const targeting = input.targeting;

  // 4. Validate targeting
  // Validate and normalize included locations
  const normalizedGeoLocations = normalizeMetaGeoLocations(
    input.targeting?.geo_locations,
    "geo_locations",
    true,
  );

  // Validate excluded locations when supplied
  const normalizedExcludedLocations = input.targeting?.excluded_geo_locations
    ? normalizeMetaGeoLocations(
      input.targeting.excluded_geo_locations,
      "excluded_geo_locations",
      false,
    )
    : undefined;
  // 1. Validate Advantage+ age range suggestion
  if (targeting.age_range !== undefined) {
    const [minAge, maxAge] = targeting.age_range;

    if (
      !Array.isArray(targeting.age_range) ||
      targeting.age_range.length !== 2 ||
      !Number.isInteger(minAge) ||
      !Number.isInteger(maxAge) ||
      minAge < 18 ||
      maxAge > 65 ||
      minAge > maxAge
    ) {
      throw new MetaAdsCampaignCreationError(
        "age_range must contain a valid [minimum, maximum] range between 18 and 65.",
        400,
      );
    }
  }

  // 2. Normalize locale IDs
  const normalizedLocales = normalizeMetaNumericOptions(
    targeting.locales,
    "locales",
  );

  // 3. Normalize education status IDs
  const normalizedEducationStatuses = normalizeMetaNumericOptions(
    targeting.education_statuses,
    "education_statuses",
  );

  // 4. Normalize relationship status IDs
  const normalizedRelationshipStatuses = normalizeMetaNumericOptions(
    targeting.relationship_statuses,
    "relationship_statuses",
  );

  // 5. Normalize college graduation years
  if (
    targeting.college_years !== undefined &&
    (
      !Array.isArray(targeting.college_years) ||
      targeting.college_years.length === 0 ||
      !targeting.college_years.every(
        (year) =>
          Number.isInteger(year) &&
          year >= 1900 &&
          year <= new Date().getFullYear() + 10,
      )
    )
  ) {
    throw new MetaAdsCampaignCreationError(
      "college_years must contain valid graduation years.",
      400,
    );
  }

  // 6. Special Ad Category restrictions
  const restrictedCategories = [
    "HOUSING",
    "EMPLOYMENT",
    "CREDIT",
  ];

  const hasRestrictedCategory = (
    input.specialAdCategories ?? []
  ).some((category) =>
    restrictedCategories.includes(category.toUpperCase()),
  );

  if (
    hasRestrictedCategory &&
    [
      targeting.age_min,
      targeting.age_max,
      targeting.age_range,
      targeting.genders,
      targeting.education_statuses,
      targeting.relationship_statuses,
      targeting.college_years,
    ].some((value) => value !== undefined)
  ) {
    throw new MetaAdsCampaignCreationError(
      "Age, gender and demographic restrictions cannot be supplied for this Special Ad Category.",
      400,
    );
  }
  // const normalizedTargeting: MetaAdsTargeting = {
  //   ...input.targeting,
  //   geo_locations: normalizedGeoLocations as MetaGeoLocations,

  //   ...(normalizedExcludedLocations && {
  //     excluded_geo_locations:
  //       normalizedExcludedLocations as MetaExcludedGeoLocations,
  //   }),
  // };
  const normalizedTargeting: MetaAdsTargeting = {
    ...input.targeting,

    geo_locations: normalizedGeoLocations as MetaGeoLocations,

    ...(normalizedExcludedLocations && {
      excluded_geo_locations:
        normalizedExcludedLocations as MetaExcludedGeoLocations,
    }),

    ...(normalizedLocales && {
      locales: normalizedLocales,
    }),

    ...(normalizedEducationStatuses && {
      education_statuses: normalizedEducationStatuses,
    }),

    ...(normalizedRelationshipStatuses && {
      relationship_statuses: normalizedRelationshipStatuses,
    }),
  };
  if (
    !targeting ||
    typeof targeting !== "object" ||
    !targeting.geo_locations ||
    !Array.isArray(targeting.geo_locations.countries) ||
    targeting.geo_locations.countries.length === 0 ||
    !targeting.geo_locations.countries.every(
      (country) =>
        typeof country === "string" && /^[A-Za-z]{2}$/.test(country.trim()),
    )
  ) {
    throw new MetaAdsCampaignCreationError(
      "At least one valid two-letter country code is required in targeting.",
      400,
    );
  }

  const countries = [
    ...new Set(
      targeting.geo_locations.countries.map((country) =>
        country.trim().toUpperCase(),
      ),
    ),
  ];

  if (
    targeting.age_min !== undefined &&
    (!Number.isInteger(targeting.age_min) ||
      targeting.age_min < 18 ||
      targeting.age_min > 65)
  ) {
    throw new MetaAdsCampaignCreationError(
      "Minimum age must be between 18 and 65.",
      400,
    );
  }

  if (
    targeting.age_max !== undefined &&
    (!Number.isInteger(targeting.age_max) ||
      targeting.age_max < 18 ||
      targeting.age_max > 65)
  ) {
    throw new MetaAdsCampaignCreationError(
      "Maximum age must be between 18 and 65.",
      400,
    );
  }

  if (
    targeting.age_min !== undefined &&
    targeting.age_max !== undefined &&
    targeting.age_min > targeting.age_max
  ) {
    throw new MetaAdsCampaignCreationError(
      "Minimum age cannot be greater than maximum age.",
      400,
    );
  }

  if (
    targeting.genders !== undefined &&
    (!Array.isArray(targeting.genders) ||
      targeting.genders.some((gender) => gender !== 1 && gender !== 2))
  ) {
    throw new MetaAdsCampaignCreationError(
      "Targeting genders must contain only 1 (male) or 2 (female).",
      400,
    );
  }

  // 5. Validate budget and currency
  let dailyBudgetMinorUnits: string | undefined;
  let bidAmountMinorUnits: string | undefined;

  if (
    input.dailyBudgetAmount !== undefined ||
    input.bidAmountInput !== undefined
  ) {
    if (!input.budgetCurrency?.trim()) {
      throw new MetaAdsCampaignCreationError(
        "Account currency is required for budget and bid amount conversion.",
        400,
      );
    }
  }

  if (input.dailyBudgetAmount !== undefined) {
    dailyBudgetMinorUnits = toMetaMinorCurrencyUnits(
      input.dailyBudgetAmount,
      input.budgetCurrency!,
    );
  }

  if (input.bidAmountInput !== undefined) {
    bidAmountMinorUnits = toMetaMinorCurrencyUnits(
      input.bidAmountInput,
      input.budgetCurrency!,
    );
  }

  // 6. Validate bidding settings
  const supportedStrategies: MetaAdsBidStrategy[] = [
    "LOWEST_COST_WITHOUT_CAP",
    "LOWEST_COST_WITH_BID_CAP",
    "COST_CAP",
    "LOWEST_COST_WITH_MIN_ROAS",
  ];

  if (
    input.bid_strategy !== undefined &&
    !supportedStrategies.includes(input.bid_strategy)
  ) {
    throw new MetaAdsCampaignCreationError(
      "Unsupported Meta Ads bid strategy.",
      400,
    );
  }

  if (
    input.bid_strategy &&
    ["LOWEST_COST_WITH_BID_CAP", "COST_CAP"].includes(input.bid_strategy) &&
    !bidAmountMinorUnits
  ) {
    throw new MetaAdsCampaignCreationError(
      "A positive bid amount is required for the selected bid strategy.",
      400,
    );
  }

  if (input.bid_constraints) {
    const roasFloor = input.bid_constraints.roas_average_floor;

    if (
      optimizationGoal !== "VALUE" ||
      !Number.isSafeInteger(roasFloor) ||
      roasFloor <= 0
    ) {
      throw new MetaAdsCampaignCreationError(
        "Minimum ROAS requires the VALUE optimization goal and a valid ROAS floor.",
        400,
      );
    }
  }

  // 7. Validate promoted object
  if (input.promoted_object !== undefined) {
    const pixelId = input.promoted_object.pixel_id?.trim();

    if (!pixelId || !/^\d+$/.test(pixelId)) {
      throw new MetaAdsCampaignCreationError(
        "A valid numeric Pixel ID is required in promoted_object.",
        400,
      );
    }
  }

  // 8. Validate mutation mode
  const validateOnly = input.validateOnly ?? true;

  if (typeof validateOnly !== "boolean") {
    throw new MetaAdsCampaignCreationError(
      "validateOnly must be a boolean.",
      400,
    );
  }

  if (!validateOnly && input.confirm !== true) {
    throw new MetaAdsCampaignCreationError(
      "Live Meta Ads Ad Set creation requires validateOnly: false and confirm: true.",
      400,
    );
  }

  // 9. Local validation-only response
  if (validateOnly) {
    return {
      validateOnly: true,
      adAccountId: context.adAccountId,
      campaignId,
      adSetId: null,
      name,
      status: "PAUSED",
      metaResponse: null,
    };
  }

  // 10. Build Meta Graph API request
  const url = new URL(
    `https://graph.facebook.com/${context.apiVersion}/${context.adAccountId}/adsets`,
  );

  const form = new URLSearchParams({
    name,
    campaign_id: campaignId,
    optimization_goal: optimizationGoal,
    billing_event: billingEvent,
    targeting: JSON.stringify(normalizedTargeting),
    status: "PAUSED",
  });

  if (dailyBudgetMinorUnits) {
    form.set("daily_budget", dailyBudgetMinorUnits);
  }

  if (input.bid_strategy) {
    form.set("bid_strategy", input.bid_strategy);
  }

  if (bidAmountMinorUnits) {
    form.set("bid_amount", bidAmountMinorUnits);
  }

  if (input.bid_constraints) {
    form.set("bid_constraints", JSON.stringify(input.bid_constraints));
  }

  if (input.promoted_object) {
    form.set("promoted_object", JSON.stringify(input.promoted_object));
  }

  // 11. Call Meta API
  let response: Response;
  let responseBody: unknown;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${context.accessToken}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(30_000),
    });

    responseBody = await response.json().catch(() => null);
  } catch (error) {
    throw new MetaAdsCampaignCreationError(
      error instanceof Error
        ? `Could not reach Meta Graph API: ${error.message}`
        : "Could not reach Meta Graph API.",
      502,
    );
  }

  if (!response.ok) {
    throw new MetaAdsCampaignCreationError(
      getMetaErrorMessage(responseBody, response.status),
      response.status,
      responseBody,
    );
  }

  // 12. Verify Meta returned an Ad Set ID
  if (
    !responseBody ||
    typeof responseBody !== "object" ||
    !("id" in responseBody) ||
    typeof (responseBody as { id?: unknown }).id !== "string"
  ) {
    throw new MetaAdsCampaignCreationError(
      "Meta Ads returned a successful response without an Ad Set ID.",
      502,
      responseBody,
    );
  }

  const adSetId = (responseBody as { id: string }).id;

  return {
    validateOnly: false,
    adAccountId: context.adAccountId,
    campaignId,
    adSetId,
    name,
    status: "PAUSED",
    metaResponse: responseBody as Record<string, unknown>,
  };
}

export async function createMetaAdsAdCreative(
  context: MetaAdsCreationContext,
  input: CreateMetaAdsAdCreativeInput,
): Promise<MetaAdsAdCreativeCreationResult> {
  // 1. Validate creative name
  const name = input.name?.trim();

  if (!name || name.length > 100) {
    throw new MetaAdsCampaignCreationError(
      "Creative name is required and must not exceed 100 characters.",
      400,
    );
  }

  // 2. Validate Facebook Page ID
  const pageId = input.pageId?.trim();

  if (!pageId || !/^\d+$/.test(pageId)) {
    throw new MetaAdsCampaignCreationError(
      "A valid numeric Facebook Page ID is required.",
      400,
    );
  }

  // 3. Validate optional Instagram Actor ID
  const instagramActorId = input.instagramActorId?.trim();

  if (instagramActorId && !/^\d+$/.test(instagramActorId)) {
    throw new MetaAdsCampaignCreationError(
      "Instagram Actor ID must be numeric.",
      400,
    );
  }

  // 4. Validate creative text
  const primaryText = input.primaryText?.trim();
  const headline = input.headline?.trim();
  const description = input.description?.trim();

  if (!primaryText || !headline) {
    throw new MetaAdsCampaignCreationError(
      "Primary text and headline are required.",
      400,
    );
  }

  // 5. Validate image and destination URLs
  const imageUrl = validateMetaHttpsUrl(input.imageUrl, "Creative image URL");

  const destinationUrl = validateMetaHttpsUrl(
    input.destinationUrl,
    "Destination URL",
  );

  // 6. Validate CTA
  const supportedCtas: MetaAdsCallToAction[] = [
    "LEARN_MORE",
    "SHOP_NOW",
    "SIGN_UP",
    "CONTACT_US",
    "GET_QUOTE",
    "DOWNLOAD",
  ];

  if (!supportedCtas.includes(input.callToAction)) {
    throw new MetaAdsCampaignCreationError(
      "Unsupported Meta Ads call-to-action type.",
      400,
    );
  }

  // 7. Validate mutation mode
  const validateOnly = input.validateOnly ?? true;

  if (typeof validateOnly !== "boolean") {
    throw new MetaAdsCampaignCreationError(
      "validateOnly must be a boolean.",
      400,
    );
  }

  if (!validateOnly && input.confirm !== true) {
    throw new MetaAdsCampaignCreationError(
      "Live Ad Creative creation requires validateOnly: false and confirm: true.",
      400,
    );
  }

  // 8. Local validation-only response
  if (validateOnly) {
    return {
      validateOnly: true,
      adAccountId: context.adAccountId,
      creativeId: null,
      name,
      pageId,
      metaResponse: null,
    };
  }

  // 9. Build the Meta Ad Creative payload
  const objectStorySpec = {
    page_id: pageId,

    ...(instagramActorId && {
      instagram_actor_id: instagramActorId,
    }),

    link_data: {
      picture: imageUrl,
      link: destinationUrl,
      message: primaryText,
      name: headline,

      ...(description && {
        description,
      }),

      call_to_action: {
        type: input.callToAction,
        value: {
          link: destinationUrl,
        },
      },
    },
  };

  // 10. Prepare Graph API request
  const url = new URL(
    `https://graph.facebook.com/${context.apiVersion}/${context.adAccountId}/adcreatives`,
  );

  const form = new URLSearchParams({
    name,
    object_story_spec: JSON.stringify(objectStorySpec),
  });

  // 11. Create Ad Creative
  let response: Response;
  let responseBody: unknown;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${context.accessToken}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(30_000),
    });

    responseBody = await response.json().catch(() => null);
  } catch (error) {
    throw new MetaAdsCampaignCreationError(
      error instanceof Error
        ? `Could not reach Meta Graph API: ${error.message}`
        : "Could not reach Meta Graph API.",
      502,
    );
  }

  // 12. Handle Meta API errors
  if (!response.ok) {
    throw new MetaAdsCampaignCreationError(
      getMetaErrorMessage(responseBody, response.status),
      response.status,
      responseBody,
    );
  }

  // 13. Verify Creative ID
  if (
    !responseBody ||
    typeof responseBody !== "object" ||
    !("id" in responseBody) ||
    typeof (responseBody as { id?: unknown }).id !== "string"
  ) {
    throw new MetaAdsCampaignCreationError(
      "Meta Ads returned a successful response without a Creative ID.",
      502,
      responseBody,
    );
  }

  const creativeId = (responseBody as { id: string }).id;

  return {
    validateOnly: false,
    adAccountId: context.adAccountId,
    creativeId,
    name,
    pageId,
    metaResponse: responseBody as Record<string, unknown>,
  };
}

/*
export async function createMetaAdsAdCreative(
  context: MetaAdsCreationContext,
  input: CreateMetaAdsAdCreativeInput,
): Promise<MetaAdsAdCreativeCreationResult> {
  // 1. Validate creative name
  const name = input.name?.trim();

  if (!name || name.length > 100) {
    throw new MetaAdsCampaignCreationError(
      "Creative name is required and must not exceed 100 characters.",
      400,
    );
  }

  // 2. Validate Facebook Page ID
  const pageId = input.pageId?.trim();

  if (!pageId || !/^\d+$/.test(pageId)) {
    throw new MetaAdsCampaignCreationError(
      "A valid numeric Facebook Page ID is required.",
      400,
    );
  }

  // 3. Validate optional Instagram Actor ID
  const instagramActorId = input.instagramActorId?.trim();

  if (instagramActorId && !/^\d+$/.test(instagramActorId)) {
    throw new MetaAdsCampaignCreationError(
      "Instagram Actor ID must be numeric.",
      400,
    );
  }

  // 4. Validate creative text
  const primaryText = input.primaryText?.trim();
  const headline = input.headline?.trim();
  const description = input.description?.trim();

  if (!primaryText || !headline) {
    throw new MetaAdsCampaignCreationError(
      "Primary text and headline are required.",
      400,
    );
  }

  // 5. Validate image and destination URLs
  const imageUrl = validateMetaHttpsUrl(
    input.imageUrl,
    "Creative image URL",
  );

  const destinationUrl = validateMetaHttpsUrl(
    input.destinationUrl,
    "Destination URL",
  );

  // 6. Validate CTA
  const supportedCtas: MetaAdsCallToAction[] = [
    "LEARN_MORE",
    "SHOP_NOW",
    "SIGN_UP",
    "CONTACT_US",
    "GET_QUOTE",
    "DOWNLOAD",
  ];

  if (!supportedCtas.includes(input.callToAction)) {
    throw new MetaAdsCampaignCreationError(
      "Unsupported Meta Ads call-to-action type.",
      400,
    );
  }

  // 7. Validate mutation mode
  const validateOnly = input.validateOnly ?? true;

  if (typeof validateOnly !== "boolean") {
    throw new MetaAdsCampaignCreationError(
      "validateOnly must be a boolean.",
      400,
    );
  }

  if (!validateOnly && input.confirm !== true) {
    throw new MetaAdsCampaignCreationError(
      "Live Ad Creative creation requires validateOnly: false and confirm: true.",
      400,
    );
  }

  // 8. Local validation-only response
  if (validateOnly) {
    return {
      validateOnly: true,
      adAccountId: context.adAccountId,
      creativeId: null,
      name,
      pageId,
      metaResponse: null,
    };
  }

  // 9. Build the Meta Ad Creative payload
  const objectStorySpec = {
    page_id: pageId,

    ...(instagramActorId && {
      instagram_actor_id: instagramActorId,
    }),

    link_data: {
      picture: imageUrl,
      link: destinationUrl,
      message: primaryText,
      name: headline,

      ...(description && {
        description,
      }),

      call_to_action: {
        type: input.callToAction,
        value: {
          link: destinationUrl,
        },
      },
    },
  };

  // 10. Prepare Graph API request
  const url = new URL(
    `https://graph.facebook.com/${context.apiVersion}/${context.adAccountId}/adcreatives`,
  );

  const form = new URLSearchParams({
    name,
    object_story_spec: JSON.stringify(objectStorySpec),
  });

  // 11. Create Ad Creative
  let response: Response;
  let responseBody: unknown;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${context.accessToken}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(30_000),
    });

    responseBody = await response.json().catch(() => null);
  } catch (error) {
    throw new MetaAdsCampaignCreationError(
      error instanceof Error
        ? `Could not reach Meta Graph API: ${error.message}`
        : "Could not reach Meta Graph API.",
      502,
    );
  }

  // 12. Handle Meta API errors
  if (!response.ok) {
    throw new MetaAdsCampaignCreationError(
      getMetaErrorMessage(responseBody, response.status),
      response.status,
      responseBody,
    );
  }

  // 13. Verify Creative ID
  if (
    !responseBody ||
    typeof responseBody !== "object" ||
    !("id" in responseBody) ||
    typeof (responseBody as { id?: unknown }).id !== "string"
  ) {
    throw new MetaAdsCampaignCreationError(
      "Meta Ads returned a successful response without a Creative ID.",
      502,
      responseBody,
    );
  }

  const creativeId = (responseBody as { id: string }).id;

  return {
    validateOnly: false,
    adAccountId: context.adAccountId,
    creativeId,
    name,
    pageId,
    metaResponse: responseBody as Record<string, unknown>,
  };
}*/

/**
 * Creates the Meta campaign object only. Ad Sets and Ads are separate steps
 * because Meta requires the campaign ID before those child resources exist.
 * All newly created campaigns remain PAUSED.
 */
export async function createMetaAdsCampaign(
  context: MetaAdsCreationContext,
  input: CreateMetaAdsCampaignInput,
): Promise<MetaAdsCampaignCreationResult> {
  const validated = validateCreateCampaignInput(input);

  if (validated.validateOnly) {
    return {
      validateOnly: true,
      adAccountId: context.adAccountId,
      campaignId: null,
      name: validated.name,
      objective: validated.objective,
      status: "PAUSED",
      buyingType: validated.buyingType,
      metaResponse: null,
    };
  }
  if (validated.dailyBudgetMinorUnits) {
    form.set("daily_budget", validated.dailyBudgetMinorUnits);
  }

  if (validated.bidStrategy) {
    form.set("bid_strategy", validated.bidStrategy);
  }

  const url = new URL(
    `https://graph.facebook.com/${context.apiVersion}/${context.adAccountId}/campaigns`,
  );

  const form = new URLSearchParams({
    name: validated.name,
    objective: validated.objective,
    status: "PAUSED",
    buying_type: validated.buyingType,
    special_ad_categories: JSON.stringify(validated.specialAdCategories),
  });

  if (validated.isAdsetBudgetSharingEnabled !== undefined) {
    form.set(
      "is_adset_budget_sharing_enabled",
      String(validated.isAdsetBudgetSharingEnabled),
    );
  }

  let response: Response;
  let responseBody: unknown;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${context.accessToken}`,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(30_000),
    });

    responseBody = await response.json().catch(() => null);
  } catch (error) {
    throw new MetaAdsCampaignCreationError(
      error instanceof Error
        ? `Could not reach Meta Graph API: ${error.message}`
        : "Could not reach Meta Graph API.",
      502,
    );
  }

  if (!response.ok) {
    throw new MetaAdsCampaignCreationError(
      getMetaErrorMessage(responseBody, response.status),
      response.status,
      responseBody,
    );
  }

  if (
    !responseBody ||
    typeof responseBody !== "object" ||
    !("id" in responseBody) ||
    typeof (responseBody as { id?: unknown }).id !== "string"
  ) {
    throw new MetaAdsCampaignCreationError(
      "Meta Ads returned a successful response without a campaign ID.",
      502,
      responseBody,
    );
  }

  return {
    validateOnly: false,
    adAccountId: context.adAccountId,
    campaignId: (responseBody as { id: string }).id,
    name: validated.name,
    objective: validated.objective,
    status: "PAUSED",
    buyingType: validated.buyingType,
    metaResponse: responseBody as Record<string, unknown>,
  };
}

/**
 * Resolve the current user's Meta credential and the selected ad account.
 * This service deliberately does not use the legacy readAccessToken() helper
 * or the Meta request-context middleware.
 */
export async function getMetaAdsCreationContext(
  userId: string,
  selectedAccountId: string,
): Promise<MetaAdsCreationContext> {
  if (!userId?.trim()) {
    throw new MetaAdsCampaignCreationError(
      "Authenticated user ID is required.",
      401,
    );
  }

  if (!selectedAccountId?.trim()) {
    throw new MetaAdsCampaignCreationError(
      "A Meta Ads account must be selected.",
      400,
    );
  }

  const adAccountId = normalizeAdAccountId(selectedAccountId);
  const accessToken = await getProviderAccessToken(userId, "metaAds");

  return {
    adAccountId,
    accessToken,
    apiVersion: getMetaApiVersion(),
  };
}

/** Convenience entry point for the global campaign route. */
export async function createMetaAdsCampaignForUser(
  userId: string,
  selectedAccountId: string,
  input: CreateMetaAdsCampaignInput,
): Promise<MetaAdsCampaignCreationResult> {
  const context = await getMetaAdsCreationContext(userId, selectedAccountId);

  const campaignResult = await createMetaAdsCampaign(context, campaignInput);

  if (!campaignResult.campaignId) {
    throw new Error("Meta campaign was not created.");
  }

  const adSetResult = await createMetaAdsAdSet(context, {
    ...adSetInput,
    campaignId: campaignResult.campaignId,
  });

  const creativeResult = await createMetaAdsAdCreative(context, creativeInput);
  return createMetaAdsCampaign(context, input);
}
